public enum Status {
    NEW,
    INPROCESS,
    FIXED,
    REALESE
}
